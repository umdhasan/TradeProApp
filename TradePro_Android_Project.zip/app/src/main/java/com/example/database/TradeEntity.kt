package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey
    val id: String,
    val assetId: String,
    val assetSymbol: String,
    val categoryName: String,
    val direction: String,
    val investment: Double,
    val entryPrice: Double,
    val exitPrice: Double,
    val payoutPercent: Int,
    val expirySeconds: Int,
    val openTime: Long,
    val closeTime: Long,
    val outcome: String,
    val profit: Double,
    val platformName: String
)
