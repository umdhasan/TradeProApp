package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alert_rules")
data class AlertRuleEntity(
    @PrimaryKey
    val id: String,
    val assetId: String,
    val assetSymbol: String,
    val alertType: String,
    val targetValue: Double,
    val isEnabled: Boolean,
    val soundEnabled: Boolean,
    val vibrationEnabled: Boolean,
    val createdAt: Long,
    val triggeredCount: Int,
    val lastTriggeredAt: Long
)

@Entity(tableName = "alert_notifications")
data class AlertNotificationEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val message: String,
    val assetSymbol: String,
    val alertType: String,
    val timestamp: Long,
    val isRead: Boolean
)
