package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SignalEntity::class,
        AlertRuleEntity::class,
        AlertNotificationEntity::class,
        TradeEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TradeProDatabase : RoomDatabase() {
    abstract fun signalDao(): SignalDao
    abstract fun alertDao(): AlertDao
    abstract fun tradeDao(): TradeDao

    companion object {
        @Volatile
        private var INSTANCE: TradeProDatabase? = null

        fun getDatabase(context: Context): TradeProDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TradeProDatabase::class.java,
                    "tradepro_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
