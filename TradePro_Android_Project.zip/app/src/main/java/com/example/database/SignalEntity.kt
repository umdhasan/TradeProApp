package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey
    val id: String,
    val assetId: String,
    val assetSymbol: String,
    val categoryName: String,
    val direction: String,
    val confidence: Int,
    val strikePrice: Double,
    val expirySeconds: Int,
    val platformName: String,
    val strategyName: String,
    val rsiValue: Double,
    val macdTrend: String,
    val timestamp: Long,
    val outcome: String,
    val resultPnl: Double
)
