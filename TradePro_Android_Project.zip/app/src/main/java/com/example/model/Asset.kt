package com.example.model

enum class MarketCategory(val displayName: String, val badgeColorHex: Long) {
    DIGITAL("Digital", 0xFF14B8A6),
    BLITZ("Blitz 5s-1m", 0xFFA855F7),
    BINARY("Binary", 0xFF38BDF8),
    CRYPTO("Crypto", 0xFFF59E0B)
}

enum class MarketPlatform(val displayName: String, val shortName: String) {
    QUOTEX("Quotex", "QX"),
    POCKET_OPTION("Pocket Option", "PO"),
    IQ_OPTION("IQ Option", "IQ"),
    BINOMO("Binomo", "BN"),
    DERIV("Deriv", "DR"),
    OLYMP_TRADE("Olymp Trade", "OT")
}

enum class ExpiryTime(val label: String, val seconds: Int, val isBlitz: Boolean = false) {
    SEC_5("5s Blitz", 5, true),
    SEC_15("15s", 15, true),
    SEC_30("30s", 30, true),
    MIN_1("1m", 60),
    MIN_2("2m", 120),
    MIN_5("5m", 300)
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val isBullish: Boolean get() = close >= open
}

data class TradingAsset(
    val id: String,
    val symbol: String,
    val name: String,
    val category: MarketCategory,
    val basePrice: Double,
    var currentPrice: Double,
    var prevPrice: Double,
    var change24h: Double,
    val high24h: Double,
    val low24h: Double,
    val payoutPercent: Int,
    val isOtc: Boolean = false,
    val priceDecimals: Int = 5,
    val candles: List<Candle> = emptyList()
) {
    val isUp: Boolean get() = currentPrice >= prevPrice
}

data class TechnicalIndicators(
    val rsi14: Double,
    val ema9: Double,
    val ema21: Double,
    val bbUpper: Double,
    val bbMiddle: Double,
    val bbLower: Double,
    val macdValue: Double,
    val macdSignal: Double,
    val macdHistogram: Double,
    val stochasticK: Double,
    val stochasticD: Double,
    val bullishSentimentPercent: Int,
    val volatilityLevel: String, // "Low", "Medium", "High", "Ultra"
    val trendRecommendation: String // "STRONG_BUY", "BUY", "NEUTRAL", "SELL", "STRONG_SELL"
)
