package com.example.model

enum class SignalDirection(val label: String, val actionText: String) {
    CALL("CALL", "BUY / UP"),
    PUT("PUT", "SELL / DOWN")
}

data class TradingSignal(
    val id: String,
    val assetId: String,
    val assetSymbol: String,
    val assetCategory: MarketCategory,
    val direction: SignalDirection,
    val confidence: Int, // e.g. 91%
    val strikePrice: Double,
    val expiryTime: ExpiryTime,
    val platform: MarketPlatform,
    val strategyName: String,
    val martingaleStep1: Double,
    val martingaleStep2: Double,
    val rsiValue: Double,
    val macdTrend: String,
    val timestamp: Long = System.currentTimeMillis(),
    val outcome: SignalOutcome = SignalOutcome.PENDING,
    val resultPnl: Double = 0.0
)

enum class SignalOutcome {
    PENDING,
    WIN,
    LOSS,
    EXPIRED
}
