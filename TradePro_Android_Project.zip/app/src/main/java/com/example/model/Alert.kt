package com.example.model

enum class AlertType(val title: String, val description: String) {
    PRICE_ABOVE("Price Rises Above", "Alert when asset price crosses higher than target"),
    PRICE_BELOW("Price Drops Below", "Alert when asset price crosses lower than target"),
    RSI_OVERSOLD("RSI Oversold (<30)", "Potential reversal BUY signal"),
    RSI_OVERBOUGHT("RSI Overbought (>70)", "Potential reversal SELL signal"),
    HIGH_WINRATE_SIGNAL("AI High Confidence Signal", "Alert when AI confidence reaches >= 85%"),
    VOLATILITY_SPIKE("Blitz Volatility Spike", "Alert on sudden sharp volume or price breakout")
}

data class AlertRule(
    val id: String,
    val assetId: String,
    val assetSymbol: String,
    val type: AlertType,
    val targetValue: Double,
    val isEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val triggeredCount: Int = 0,
    val lastTriggeredAt: Long = 0L
)

data class AlertNotification(
    val id: String,
    val title: String,
    val message: String,
    val assetSymbol: String,
    val type: AlertType,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
