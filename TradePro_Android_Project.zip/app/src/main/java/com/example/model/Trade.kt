package com.example.model

data class SimulationTrade(
    val id: String,
    val assetId: String,
    val assetSymbol: String,
    val category: MarketCategory,
    val direction: SignalDirection,
    val investment: Double,
    val entryPrice: Double,
    var exitPrice: Double = 0.0,
    val payoutPercent: Int,
    val expirySeconds: Int,
    val openTime: Long = System.currentTimeMillis(),
    val closeTime: Long = openTime + (expirySeconds * 1000L),
    var outcome: SignalOutcome = SignalOutcome.PENDING,
    var profit: Double = 0.0,
    val platform: MarketPlatform = MarketPlatform.QUOTEX
) {
    val isPending: Boolean get() = outcome == SignalOutcome.PENDING
}
