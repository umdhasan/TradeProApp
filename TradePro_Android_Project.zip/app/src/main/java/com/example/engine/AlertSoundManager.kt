package com.example.engine

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

class AlertSoundManager(private val context: Context) {

    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 95)
        } catch (e: Exception) {
            Log.e("AlertSoundManager", "ToneGenerator init failed", e)
        }
    }

    fun playCallAlert() {
        try {
            // Uplifting high tone for CALL / BUY
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 220)
            vibrate(longArrayOf(0, 100, 80, 150))
        } catch (e: Exception) {
            Log.e("AlertSoundManager", "playCallAlert failed", e)
        }
    }

    fun playPutAlert() {
        try {
            // Resonant low tone for PUT / SELL
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 250)
            vibrate(longArrayOf(0, 150, 70, 120))
        } catch (e: Exception) {
            Log.e("AlertSoundManager", "playPutAlert failed", e)
        }
    }

    fun playUrgentAlert() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 350)
            vibrate(longArrayOf(0, 200, 100, 200, 100, 250))
        } catch (e: Exception) {
            Log.e("AlertSoundManager", "playUrgentAlert failed", e)
        }
    }

    fun playClickSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 70)
        } catch (_: Exception) {}
    }

    private fun vibrate(pattern: LongArray) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            Log.e("AlertSoundManager", "Vibrate error", e)
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}
    }
}
