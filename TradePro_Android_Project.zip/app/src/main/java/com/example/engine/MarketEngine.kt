package com.example.engine

import com.example.model.Candle
import com.example.model.MarketCategory
import com.example.model.TradingAsset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class MarketEngine(private val scope: CoroutineScope) {

    private val _assets = MutableStateFlow<List<TradingAsset>>(emptyList())
    val assets: StateFlow<List<TradingAsset>> = _assets.asStateFlow()

    private val _selectedAssetId = MutableStateFlow<String>("dig_eur_usd")
    val selectedAssetId: StateFlow<String> = _selectedAssetId.asStateFlow()

    init {
        initializeAssets()
        startLiveMarketFeed()
    }

    private fun initializeAssets() {
        val initialList = listOf(
            // --- DIGITAL ASSETS ---
            createInitialAsset("dig_eur_usd", "EUR/USD", "Euro / US Dollar", MarketCategory.DIGITAL, 1.08640, 5, 93, isOtc = false),
            createInitialAsset("dig_gbp_usd", "GBP/USD", "British Pound / US Dollar", MarketCategory.DIGITAL, 1.29420, 5, 89, isOtc = false),
            createInitialAsset("dig_usd_jpy", "USD/JPY", "US Dollar / Japanese Yen", MarketCategory.DIGITAL, 154.680, 3, 91, isOtc = false),
            createInitialAsset("dig_aud_usd", "AUD/USD", "Australian Dollar / US Dollar", MarketCategory.DIGITAL, 0.65820, 5, 87, isOtc = false),
            createInitialAsset("dig_eur_gbp_otc", "EUR/GBP (OTC)", "Euro / British Pound OTC", MarketCategory.DIGITAL, 0.83940, 5, 94, isOtc = true),
            createInitialAsset("dig_usd_cad_otc", "USD/CAD (OTC)", "US Dollar / Canadian Dollar OTC", MarketCategory.DIGITAL, 1.38550, 5, 95, isOtc = true),

            // --- BLITZ ASSETS (Ultra fast expiry 5s-1m) ---
            createInitialAsset("blitz_eur_usd", "Blitz EUR/USD", "Blitz Fast Euro Option", MarketCategory.BLITZ, 1.08645, 5, 96, isOtc = true),
            createInitialAsset("blitz_btc", "Blitz BTC", "Blitz Fast Bitcoin Option", MarketCategory.BLITZ, 89450.0, 2, 98, isOtc = false),
            createInitialAsset("blitz_xau_usd", "Blitz Gold", "Blitz Gold (XAU/USD)", MarketCategory.BLITZ, 2735.60, 2, 95, isOtc = true),
            createInitialAsset("blitz_gbp_jpy", "Blitz GBP/JPY", "Blitz Pound / Yen High Volatility", MarketCategory.BLITZ, 199.850, 3, 94, isOtc = true),
            createInitialAsset("blitz_eth", "Blitz ETH", "Blitz Fast Ethereum Option", MarketCategory.BLITZ, 3420.50, 2, 95, isOtc = false),

            // --- BINARY ASSETS ---
            createInitialAsset("bin_eur_usd", "EUR/USD Binary", "Standard High/Low Binary", MarketCategory.BINARY, 1.08630, 5, 92, isOtc = false),
            createInitialAsset("bin_gbp_usd", "GBP/USD Binary", "Pound Call/Put Option", MarketCategory.BINARY, 1.29410, 5, 90, isOtc = false),
            createInitialAsset("bin_usd_chf", "USD/CHF Binary", "Swiss Franc Option", MarketCategory.BINARY, 0.88420, 5, 88, isOtc = false),
            createInitialAsset("bin_aud_cad", "AUD/CAD Binary", "Aussie / Canadian Dollar", MarketCategory.BINARY, 0.91240, 5, 91, isOtc = false),
            createInitialAsset("bin_usd_jpy", "USD/JPY Binary", "Yen Binary Contract", MarketCategory.BINARY, 154.650, 3, 93, isOtc = false),

            // --- CRYPTO ASSETS ---
            createInitialAsset("cry_btc_usdt", "BTC/USDT", "Bitcoin", MarketCategory.CRYPTO, 89480.0, 2, 94, isOtc = false),
            createInitialAsset("cry_eth_usdt", "ETH/USDT", "Ethereum", MarketCategory.CRYPTO, 3422.0, 2, 92, isOtc = false),
            createInitialAsset("cry_sol_usdt", "SOL/USDT", "Solana", MarketCategory.CRYPTO, 218.40, 2, 91, isOtc = false),
            createInitialAsset("cry_xrp_usdt", "XRP/USDT", "Ripple", MarketCategory.CRYPTO, 1.1450, 4, 88, isOtc = false),
            createInitialAsset("cry_bnb_usdt", "BNB/USDT", "Binance Coin", MarketCategory.CRYPTO, 648.20, 2, 90, isOtc = false),
            createInitialAsset("cry_doge_usdt", "DOGE/USDT", "Dogecoin", MarketCategory.CRYPTO, 0.3840, 4, 86, isOtc = false)
        )
        _assets.value = initialList
    }

    private fun createInitialAsset(
        id: String,
        symbol: String,
        name: String,
        category: MarketCategory,
        basePrice: Double,
        decimals: Int,
        payout: Int,
        isOtc: Boolean
    ): TradingAsset {
        val candles = generateHistoricalCandles(basePrice, 45, decimals)
        val current = candles.last().close
        val prev = candles[candles.size - 2].close
        val high = candles.maxOf { it.high }
        val low = candles.minOf { it.low }
        val change = ((current - candles.first().open) / candles.first().open) * 100.0

        return TradingAsset(
            id = id,
            symbol = symbol,
            name = name,
            category = category,
            basePrice = basePrice,
            currentPrice = current,
            prevPrice = prev,
            change24h = change,
            high24h = high,
            low24h = low,
            payoutPercent = payout,
            isOtc = isOtc,
            priceDecimals = decimals,
            candles = candles
        )
    }

    private fun generateHistoricalCandles(basePrice: Double, count: Int, decimals: Int): List<Candle> {
        val list = mutableListOf<Candle>()
        var price = basePrice
        val now = System.currentTimeMillis()
        val intervalMs = 60_000L // 1-minute historical candles
        val start = now - (count * intervalMs)

        for (i in 0 until count) {
            val deltaPct = (Random.nextDouble() - 0.495) * 0.003
            val open = price
            price = (price * (1.0 + deltaPct)).coerceAtLeast(0.00001)
            val close = price
            val spread = kotlin.math.abs(open - close) + (open * 0.0008 * Random.nextDouble())
            val high = maxOf(open, close) + spread * Random.nextDouble()
            val low = minOf(open, close) - spread * Random.nextDouble()
            val volume = 1000.0 + Random.nextDouble() * 5000.0

            list.add(
                Candle(
                    timestamp = start + (i * intervalMs),
                    open = round(open, decimals),
                    high = round(high, decimals),
                    low = round(low, decimals),
                    close = round(close, decimals),
                    volume = volume
                )
            )
        }
        return list
    }

    private fun startLiveMarketFeed() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(850L) // Real-time tick frequency
                val updatedList = _assets.value.map { asset ->
                    // Dynamic volatility based on category
                    val volatilityFactor = when (asset.category) {
                        MarketCategory.BLITZ -> 0.0016
                        MarketCategory.CRYPTO -> 0.0012
                        MarketCategory.DIGITAL -> 0.0006
                        MarketCategory.BINARY -> 0.0007
                    }

                    val tickPct = (Random.nextDouble() - 0.498) * volatilityFactor
                    val oldPrice = asset.currentPrice
                    val newPrice = round(oldPrice * (1.0 + tickPct), asset.priceDecimals)

                    // Update last candle
                    val currentCandles = asset.candles.toMutableList()
                    if (currentCandles.isNotEmpty()) {
                        val lastCandle = currentCandles.last()
                        val updatedCandle = lastCandle.copy(
                            high = maxOf(lastCandle.high, newPrice),
                            low = minOf(lastCandle.low, newPrice),
                            close = newPrice,
                            volume = lastCandle.volume + Random.nextDouble() * 40.0
                        )
                        currentCandles[currentCandles.size - 1] = updatedCandle
                    }

                    val high24 = maxOf(asset.high24h, newPrice)
                    val low24 = minOf(asset.low24h, newPrice)
                    val change = ((newPrice - asset.basePrice) / asset.basePrice) * 100.0

                    asset.copy(
                        currentPrice = newPrice,
                        prevPrice = oldPrice,
                        change24h = change,
                        high24h = high24,
                        low24h = low24,
                        candles = currentCandles
                    )
                }
                _assets.value = updatedList
            }
        }
    }

    fun selectAsset(assetId: String) {
        _selectedAssetId.value = assetId
    }

    fun getSelectedAsset(): TradingAsset? {
        val id = _selectedAssetId.value
        return _assets.value.firstOrNull { it.id == id } ?: _assets.value.firstOrNull()
    }

    private fun round(value: Double, decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10.0 }
        return kotlin.math.round(value * multiplier) / multiplier
    }
}
