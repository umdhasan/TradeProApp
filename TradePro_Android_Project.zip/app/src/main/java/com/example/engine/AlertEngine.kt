package com.example.engine

import com.example.database.AlertDao
import com.example.database.AlertNotificationEntity
import com.example.database.AlertRuleEntity
import com.example.model.AlertNotification
import com.example.model.AlertRule
import com.example.model.AlertType
import com.example.model.ExpiryTime
import com.example.model.MarketPlatform
import com.example.model.TradingAsset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AlertEngine(
    private val scope: CoroutineScope,
    private val alertDao: AlertDao,
    private val marketEngine: MarketEngine,
    private val soundManager: AlertSoundManager
) {

    private val _isAutoScannerActive = MutableStateFlow<Boolean>(true)
    val isAutoScannerActive: StateFlow<Boolean> = _isAutoScannerActive.asStateFlow()

    private val _minConfidenceThreshold = MutableStateFlow<Int>(85)
    val minConfidenceThreshold: StateFlow<Int> = _minConfidenceThreshold.asStateFlow()

    private val _latestAlert = MutableStateFlow<AlertNotification?>(null)
    val latestAlert: StateFlow<AlertNotification?> = _latestAlert.asStateFlow()

    private val lastTriggeredCache = mutableMapOf<String, Long>()

    init {
        startScannerLoop()
    }

    fun setAutoScannerActive(active: Boolean) {
        _isAutoScannerActive.value = active
    }

    fun setMinConfidenceThreshold(threshold: Int) {
        _minConfidenceThreshold.value = threshold
    }

    fun dismissLatestAlert() {
        _latestAlert.value = null
    }

    private fun startScannerLoop() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(3000L) // Scan check every 3 seconds
                if (!_isAutoScannerActive.value) continue

                val assets = marketEngine.assets.value
                val now = System.currentTimeMillis()

                // 1. Scan for High Confidence AI Signals
                for (asset in assets) {
                    val indicators = TechnicalAnalysisEngine.analyze(asset.candles)
                    val signal = SignalEngine.generateSignal(
                        asset = asset,
                        indicators = indicators,
                        platform = MarketPlatform.QUOTEX,
                        expiryTime = ExpiryTime.MIN_1
                    )

                    if (signal.confidence >= _minConfidenceThreshold.value) {
                        val cacheKey = "sig_${asset.id}_${signal.direction}"
                        val lastTime = lastTriggeredCache[cacheKey] ?: 0L
                        // Cooldown 40 seconds per asset signal
                        if (now - lastTime > 40_000L) {
                            lastTriggeredCache[cacheKey] = now
                            triggerSignalAlert(asset, signal.direction.label, signal.confidence, signal.strategyName)
                            break // Trigger one prominent alert per scan cycle
                        }
                    }

                    // 2. Scan for Technical Overbought / Oversold triggers
                    if (indicators.rsi14 <= 28.0) {
                        val cacheKey = "rsi_os_${asset.id}"
                        val lastTime = lastTriggeredCache[cacheKey] ?: 0L
                        if (now - lastTime > 60_000L) {
                            lastTriggeredCache[cacheKey] = now
                            triggerTechnicalAlert(
                                asset = asset,
                                title = "RSI Oversold Alert: ${asset.symbol}",
                                message = "RSI dropped to ${String.format("%.1f", indicators.rsi14)}! High probability bullish reversal setup.",
                                type = AlertType.RSI_OVERSOLD
                            )
                            break
                        }
                    } else if (indicators.rsi14 >= 72.0) {
                        val cacheKey = "rsi_ob_${asset.id}"
                        val lastTime = lastTriggeredCache[cacheKey] ?: 0L
                        if (now - lastTime > 60_000L) {
                            lastTriggeredCache[cacheKey] = now
                            triggerTechnicalAlert(
                                asset = asset,
                                title = "RSI Overbought Alert: ${asset.symbol}",
                                message = "RSI spiked to ${String.format("%.1f", indicators.rsi14)}! High probability bearish rejection setup.",
                                type = AlertType.RSI_OVERBOUGHT
                            )
                            break
                        }
                    }
                }
            }
        }
    }

    private fun triggerSignalAlert(asset: TradingAsset, direction: String, confidence: Int, strategy: String) {
        val title = "⚡ AI Signal Alert: $direction on ${asset.symbol}"
        val message = "$confidence% Confidence setup detected via $strategy at price ${asset.currentPrice}."

        if (direction == "CALL") {
            soundManager.playCallAlert()
        } else {
            soundManager.playPutAlert()
        }

        val notification = AlertNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            assetSymbol = asset.symbol,
            type = AlertType.HIGH_WINRATE_SIGNAL,
            timestamp = System.currentTimeMillis()
        )

        _latestAlert.value = notification
        saveNotification(notification)
    }

    private fun triggerTechnicalAlert(
        asset: TradingAsset,
        title: String,
        message: String,
        type: AlertType
    ) {
        soundManager.playUrgentAlert()

        val notification = AlertNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            assetSymbol = asset.symbol,
            type = type,
            timestamp = System.currentTimeMillis()
        )

        _latestAlert.value = notification
        saveNotification(notification)
    }

    private fun saveNotification(notif: AlertNotification) {
        scope.launch(Dispatchers.IO) {
            try {
                alertDao.insertNotification(
                    AlertNotificationEntity(
                        id = notif.id,
                        title = notif.title,
                        message = notif.message,
                        assetSymbol = notif.assetSymbol,
                        alertType = notif.type.name,
                        timestamp = notif.timestamp,
                        isRead = false
                    )
                )
            } catch (_: Exception) {}
        }
    }

    fun addCustomAlertRule(rule: AlertRule) {
        scope.launch(Dispatchers.IO) {
            alertDao.insertRule(
                AlertRuleEntity(
                    id = rule.id,
                    assetId = rule.assetId,
                    assetSymbol = rule.assetSymbol,
                    alertType = rule.type.name,
                    targetValue = rule.targetValue,
                    isEnabled = rule.isEnabled,
                    soundEnabled = rule.soundEnabled,
                    vibrationEnabled = rule.vibrationEnabled,
                    createdAt = rule.createdAt,
                    triggeredCount = 0,
                    lastTriggeredAt = 0L
                )
            )
        }
    }

    fun deleteCustomAlertRule(ruleId: String) {
        scope.launch(Dispatchers.IO) {
            alertDao.deleteRule(
                AlertRuleEntity(
                    id = ruleId,
                    assetId = "",
                    assetSymbol = "",
                    alertType = "",
                    targetValue = 0.0,
                    isEnabled = false,
                    soundEnabled = false,
                    vibrationEnabled = false,
                    createdAt = 0L,
                    triggeredCount = 0,
                    lastTriggeredAt = 0L
                )
            )
        }
    }
}
