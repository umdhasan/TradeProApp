package com.example.engine

import com.example.model.ExpiryTime
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.SignalDirection
import com.example.model.TechnicalIndicators
import com.example.model.TradingAsset
import com.example.model.TradingSignal
import java.util.UUID
import kotlin.math.roundToInt
import kotlin.random.Random

object SignalEngine {

    fun generateSignal(
        asset: TradingAsset,
        indicators: TechnicalIndicators,
        platform: MarketPlatform,
        expiryTime: ExpiryTime,
        baseTradeAmount: Double = 10.0
    ): TradingSignal {
        // Confluence calculation based on indicators & asset type
        val rsiScore = when {
            indicators.rsi14 < 32 -> 1.0 // Strong Call
            indicators.rsi14 > 68 -> -1.0 // Strong Put
            indicators.rsi14 < 45 -> 0.4
            indicators.rsi14 > 55 -> -0.4
            else -> 0.0
        }

        val emaScore = if (indicators.ema9 > indicators.ema21) 0.8 else -0.8
        val macdScore = if (indicators.macdHistogram > 0) 0.6 else -0.6
        val stochScore = when {
            indicators.stochasticK < 25 -> 0.7
            indicators.stochasticK > 75 -> -0.7
            else -> 0.0
        }
        val sentimentScore = ((indicators.bullishSentimentPercent - 50.0) / 50.0) * 0.5

        val totalScore = rsiScore + emaScore + macdScore + stochScore + sentimentScore

        val direction = if (totalScore >= 0) SignalDirection.CALL else SignalDirection.PUT

        // Calculate confidence percentage (82% to 96%)
        val baseConfidence = 82
        val bonus = (kotlin.math.abs(totalScore) * 4.5).roundToInt().coerceIn(0, 14)
        val jitter = Random.nextInt(0, 2)
        val confidence = (baseConfidence + bonus + jitter).coerceIn(80, 96)

        // Select the most fitting strategy label
        val strategy = when {
            asset.category == MarketCategory.BLITZ -> {
                if (direction == SignalDirection.CALL) "Blitz Micro-Momentum Surge"
                else "Blitz Rapid Resistance Rejection"
            }
            indicators.rsi14 < 30 || indicators.rsi14 > 70 -> {
                "RSI Extreme Mean Reversion (14)"
            }
            kotlin.math.abs(indicators.macdHistogram) > 0.0001 -> {
                "MACD Trend Confluence + Volume"
            }
            else -> {
                "EMA 9/21 Dynamic Channel Cross"
            }
        }

        // Martingale calculation (Standard binary/digital 2.2x multiplier)
        val step1 = baseTradeAmount * 2.2
        val step2 = step1 * 2.3

        return TradingSignal(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            assetCategory = asset.category,
            direction = direction,
            confidence = confidence,
            strikePrice = asset.currentPrice,
            expiryTime = expiryTime,
            platform = platform,
            strategyName = strategy,
            martingaleStep1 = roundToTwoDecimals(step1),
            martingaleStep2 = roundToTwoDecimals(step2),
            rsiValue = roundToTwoDecimals(indicators.rsi14),
            macdTrend = if (indicators.macdHistogram >= 0) "Bullish Convergence" else "Bearish Divergence"
        )
    }

    private fun roundToTwoDecimals(value: Double): Double {
        return kotlin.math.round(value * 100.0) / 100.0
    }
}
