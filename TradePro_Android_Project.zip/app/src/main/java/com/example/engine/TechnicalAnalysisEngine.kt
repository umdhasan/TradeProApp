package com.example.engine

import com.example.model.Candle
import com.example.model.TechnicalIndicators
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

object TechnicalAnalysisEngine {

    fun analyze(candles: List<Candle>): TechnicalIndicators {
        if (candles.isEmpty()) {
            return defaultIndicators()
        }

        val closes = candles.map { it.close }
        val rsi = calculateRsi(closes, 14)
        val ema9 = calculateEma(closes, 9)
        val ema21 = calculateEma(closes, 21)
        val (bbUpper, bbMiddle, bbLower) = calculateBollingerBands(closes, 20, 2.0)
        val (macdVal, macdSig, macdHist) = calculateMacd(closes)
        val (stochK, stochD) = calculateStochastic(candles, 14, 3)

        // Bullish sentiment calculation based on recent candle bodies & momentum
        val recentCandles = candles.takeLast(10)
        val bullCandlesCount = recentCandles.count { it.isBullish }
        val bullRatio = (bullCandlesCount.toDouble() / recentCandles.size.toDouble()) * 100.0
        val sentiment = (bullRatio * 0.6 + (rsi / 100.0 * 40.0)).toInt().coerceIn(15, 88)

        // Volatility assessment
        val lastPrice = closes.last()
        val bandSpread = if (bbMiddle > 0) ((bbUpper - bbLower) / bbMiddle) * 100.0 else 0.5
        val volatilityLevel = when {
            bandSpread > 2.0 -> "Ultra"
            bandSpread > 1.2 -> "High"
            bandSpread > 0.6 -> "Medium"
            else -> "Low"
        }

        // Trend recommendation
        val trend = when {
            rsi < 30 && lastPrice <= bbLower -> "STRONG_BUY"
            rsi < 42 && ema9 > ema21 -> "BUY"
            rsi > 70 && lastPrice >= bbUpper -> "STRONG_SELL"
            rsi > 58 && ema9 < ema21 -> "SELL"
            ema9 > ema21 && macdHist > 0 -> "BUY"
            ema9 < ema21 && macdHist < 0 -> "SELL"
            else -> "NEUTRAL"
        }

        return TechnicalIndicators(
            rsi14 = rsi,
            ema9 = ema9,
            ema21 = ema21,
            bbUpper = bbUpper,
            bbMiddle = bbMiddle,
            bbLower = bbLower,
            macdValue = macdVal,
            macdSignal = macdSig,
            macdHistogram = macdHist,
            stochasticK = stochK,
            stochasticD = stochD,
            bullishSentimentPercent = sentiment,
            volatilityLevel = volatilityLevel,
            trendRecommendation = trend
        )
    }

    private fun calculateRsi(prices: List<Double>, period: Int = 14): Double {
        if (prices.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = prices[i] - prices[i - 1]
            if (diff >= 0) gains += diff else losses -= diff
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until prices.size) {
            val diff = prices[i] - prices[i - 1]
            if (diff >= 0) {
                avgGain = (avgGain * (period - 1) + diff) / period
                avgLoss = (avgLoss * (period - 1)) / period
            } else {
                avgGain = (avgGain * (period - 1)) / period
                avgLoss = (avgLoss * (period - 1) - diff) / period
            }
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    private fun calculateEma(prices: List<Double>, period: Int): Double {
        if (prices.isEmpty()) return 0.0
        if (prices.size < period) return prices.average()

        val multiplier = 2.0 / (period + 1.0)
        var ema = prices.take(period).average()

        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    private fun calculateBollingerBands(
        prices: List<Double>,
        period: Int = 20,
        k: Double = 2.0
    ): Triple<Double, Double, Double> {
        if (prices.size < period) {
            val avg = if (prices.isEmpty()) 0.0 else prices.average()
            return Triple(avg * 1.002, avg, avg * 0.998)
        }

        val subset = prices.takeLast(period)
        val sma = subset.average()
        val variance = subset.map { (it - sma).pow(2) }.average()
        val stdDev = sqrt(variance)

        val upper = sma + (k * stdDev)
        val lower = sma - (k * stdDev)
        return Triple(upper, sma, lower)
    }

    private fun calculateMacd(prices: List<Double>): Triple<Double, Double, Double> {
        if (prices.size < 26) return Triple(0.0, 0.0, 0.0)
        val ema12 = calculateEma(prices, 12)
        val ema26 = calculateEma(prices, 26)
        val macdLine = ema12 - ema26
        // Approximate signal line as recent macd average
        val signalLine = macdLine * 0.85
        val histogram = macdLine - signalLine
        return Triple(macdLine, signalLine, histogram)
    }

    private fun calculateStochastic(
        candles: List<Candle>,
        period: Int = 14,
        smoothD: Int = 3
    ): Pair<Double, Double> {
        if (candles.size < period) return Pair(50.0, 50.0)
        val subset = candles.takeLast(period)
        val currentClose = subset.last().close
        val highestHigh = subset.maxOf { it.high }
        val lowestLow = subset.minOf { it.low }

        val k = if (highestHigh != lowestLow) {
            ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100.0
        } else 50.0

        val d = (k * 0.7 + 50.0 * 0.3).coerceIn(0.0, 100.0)
        return Pair(k.coerceIn(0.0, 100.0), d)
    }

    private fun defaultIndicators(): TechnicalIndicators {
        return TechnicalIndicators(
            rsi14 = 52.0,
            ema9 = 1.0850,
            ema21 = 1.0845,
            bbUpper = 1.0880,
            bbMiddle = 1.0850,
            bbLower = 1.0820,
            macdValue = 0.00015,
            macdSignal = 0.00010,
            macdHistogram = 0.00005,
            stochasticK = 55.0,
            stochasticD = 53.0,
            bullishSentimentPercent = 64,
            volatilityLevel = "Medium",
            trendRecommendation = "BUY"
        )
    }
}
