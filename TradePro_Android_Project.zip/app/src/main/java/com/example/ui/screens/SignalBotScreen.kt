package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.SignalEntity
import com.example.model.ExpiryTime
import com.example.model.MarketPlatform
import com.example.model.SignalDirection
import com.example.model.TradingSignal
import com.example.ui.TradeProViewModel
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SignalBotScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val selectedPlatform by viewModel.selectedPlatform.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val isGenerating by viewModel.isGeneratingSignal.collectAsState()
    val activeSignal by viewModel.activeSignal.collectAsState()
    val savedSignals by viewModel.savedSignals.collectAsState()

    var assetMenuExpanded by remember { mutableStateOf(false) }
    var platformMenuExpanded by remember { mutableStateOf(false) }

    val asset = selectedAsset ?: return
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 14.dp)
            .testTag("signal_bot_screen")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Hero Title Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(CyberCyan.copy(alpha = 0.15f), CardSurface)
                    )
                )
                .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCyan.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "AI TRADING SIGNALS ENGINE",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Multi-Timeframe Confluence & Risk Optimizer",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selectors: Asset & Platform
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Asset Selector
            Box(modifier = Modifier.weight(1f)) {
                Column {
                    Text("TARGET ASSET", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurface)
                            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                            .clickable { assetMenuExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(asset.symbol, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }

                DropdownMenu(
                    expanded = assetMenuExpanded,
                    onDismissRequest = { assetMenuExpanded = false },
                    modifier = Modifier.background(CardSurfaceElevated)
                ) {
                    allAssets.forEach { a ->
                        DropdownMenuItem(
                            text = { Text(a.symbol, color = TextPrimary, fontWeight = FontWeight.Bold) },
                            onClick = {
                                viewModel.selectAsset(a.id)
                                assetMenuExpanded = false
                            }
                        )
                    }
                }
            }

            // Platform Selector
            Box(modifier = Modifier.weight(1f)) {
                Column {
                    Text("BROKER PLATFORM", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurface)
                            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                            .clickable { platformMenuExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(selectedPlatform.displayName, color = CyberCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                    }
                }

                DropdownMenu(
                    expanded = platformMenuExpanded,
                    onDismissRequest = { platformMenuExpanded = false },
                    modifier = Modifier.background(CardSurfaceElevated)
                ) {
                    MarketPlatform.values().forEach { p ->
                        DropdownMenuItem(
                            text = { Text(p.displayName, color = TextPrimary) },
                            onClick = {
                                viewModel.setPlatform(p)
                                platformMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Timeframe Selector
        Column {
            Text("EXPIRATION TIMEFRAME", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ExpiryTime.values()) { expiry ->
                    val isSel = selectedTimeframe == expiry
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                            .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(8.dp))
                            .clickable { viewModel.setTimeframe(expiry) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = expiry.label,
                            color = if (isSel) CyberCyan else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Action Button: GENERATE AI SIGNAL
        Button(
            onClick = { viewModel.generateSignalForSelectedAsset() },
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
            shape = RoundedCornerShape(12.dp),
            enabled = !isGenerating,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("generate_signal_button")
        ) {
            if (isGenerating) {
                CircularProgressIndicator(
                    color = DarkNavyBg,
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "CALCULATING CONFLUENCE...",
                    color = DarkNavyBg,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Icon(Icons.Default.FlashOn, contentDescription = null, tint = DarkNavyBg, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "GENERATE AI SIGNAL (${asset.symbol})",
                    color = DarkNavyBg,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Active Generated Signal Card
        activeSignal?.let { signal ->
            SignalResultCard(
                signal = signal,
                onTradeNow = {
                    viewModel.executeTrade(signal.direction)
                }
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Recent Signal History
        Text(
            text = "RECENT GENERATED SIGNALS",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (savedSignals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No signals generated yet. Tap 'Generate AI Signal' above!",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        } else {
            savedSignals.take(6).forEach { sig ->
                SavedSignalItem(signal = sig)
                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
fun SignalResultCard(
    signal: TradingSignal,
    onTradeNow: () -> Unit
) {
    val isCall = signal.direction == SignalDirection.CALL
    val actionColor = if (isCall) BullishGreen else BearishRed

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, actionColor.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
            .testTag("signal_result_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Signal Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(actionColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = signal.direction.label,
                            tint = actionColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${signal.direction.label} • ${signal.direction.actionText}",
                            color = actionColor,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${signal.assetSymbol} • ${signal.platform.displayName}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Confidence Meter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(actionColor.copy(alpha = 0.15f))
                        .border(1.dp, actionColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${signal.confidence}% ACCURACY",
                        color = actionColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Strategy Confluence
            Text(
                text = "STRATEGY: ${signal.strategyName}",
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Details Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoBox(label = "STRIKE PRICE", value = signal.strikePrice.toString(), modifier = Modifier.weight(1f))
                InfoBox(label = "EXPIRY", value = signal.expiryTime.label, modifier = Modifier.weight(1f))
                InfoBox(label = "RSI (14)", value = signal.rsiValue.toString(), modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Martingale Risk Plan
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurfaceElevated)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("MARTINGALE RECOVERY PLAN", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("Safe 2-Step", color = CryptoGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Base: $10.00", color = TextPrimary, fontSize = 11.sp)
                    Text("Step 1: $${signal.martingaleStep1}", color = CryptoGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("Step 2: $${signal.martingaleStep2}", color = BearishRed, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Execution Button
            Button(
                onClick = onTradeNow,
                colors = ButtonDefaults.buttonColors(containerColor = actionColor),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Text(
                    text = "EXECUTE DEMO TRADE NOW",
                    color = if (isCall) Color.Black else Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun InfoBox(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CardSurfaceElevated)
            .padding(6.dp)
    ) {
        Column {
            Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(1.dp))
            Text(value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
fun SavedSignalItem(signal: SignalEntity) {
    val isCall = signal.direction == "CALL"
    val color = if (isCall) BullishGreen else BearishRed
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "${signal.assetSymbol} ${signal.direction} (${signal.confidence}%)",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${signal.strategyName} • ${signal.platformName}",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }

        Text(
            text = dateFormat.format(Date(signal.timestamp)),
            color = TextSecondary,
            fontSize = 10.sp
        )
    }
}
