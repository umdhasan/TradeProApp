package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TechnicalIndicators
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow

@Composable
fun TechnicalIndicatorsPanel(
    indicators: TechnicalIndicators,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
            .testTag("technical_indicators_panel")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TECHNICAL ANALYTICS",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            // Recommendation Badge
            val (recColor, recBg) = when (indicators.trendRecommendation) {
                "STRONG_BUY", "BUY" -> Pair(BullishGreen, BullishGreen.copy(alpha = 0.15f))
                "STRONG_SELL", "SELL" -> Pair(BearishRed, BearishRed.copy(alpha = 0.15f))
                else -> Pair(WarningYellow, WarningYellow.copy(alpha = 0.15f))
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(recBg)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = indicators.trendRecommendation.replace("_", " "),
                    color = recColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Grid of 4 Key Indicators
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // RSI 14 Card
            IndicatorMiniCard(
                title = "RSI (14)",
                value = String.format("%.1f", indicators.rsi14),
                subtitle = when {
                    indicators.rsi14 < 30 -> "Oversold"
                    indicators.rsi14 > 70 -> "Overbought"
                    else -> "Neutral"
                },
                valueColor = when {
                    indicators.rsi14 < 30 -> BullishGreen
                    indicators.rsi14 > 70 -> BearishRed
                    else -> CyberCyan
                },
                modifier = Modifier.weight(1f)
            )

            // Stochastic Card
            IndicatorMiniCard(
                title = "Stoch %K",
                value = String.format("%.1f", indicators.stochasticK),
                subtitle = "%D: ${String.format("%.1f", indicators.stochasticD)}",
                valueColor = when {
                    indicators.stochasticK < 20 -> BullishGreen
                    indicators.stochasticK > 80 -> BearishRed
                    else -> TextPrimary
                },
                modifier = Modifier.weight(1f)
            )

            // MACD Card
            IndicatorMiniCard(
                title = "MACD",
                value = if (indicators.macdHistogram >= 0) "+Bull" else "-Bear",
                subtitle = "Hist: ${String.format("%.4f", indicators.macdHistogram)}",
                valueColor = if (indicators.macdHistogram >= 0) BullishGreen else BearishRed,
                modifier = Modifier.weight(1f)
            )

            // Volatility Card
            IndicatorMiniCard(
                title = "Volatility",
                value = indicators.volatilityLevel,
                subtitle = "ATR Band",
                valueColor = when (indicators.volatilityLevel) {
                    "Ultra", "High" -> CryptoGold
                    "Medium" -> CyberCyan
                    else -> TextSecondary
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bullish vs Bearish Sentiment Ratio
        val bullPct = indicators.bullishSentimentPercent
        val bearPct = 100 - bullPct

        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "BUYERS $bullPct%",
                    color = BullishGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ORDER FLOW SENTIMENT",
                    color = TextMuted,
                    fontSize = 10.sp
                )
                Text(
                    text = "$bearPct% SELLERS",
                    color = BearishRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            ) {
                Box(
                    modifier = Modifier
                        .weight(bullPct.toFloat().coerceAtLeast(1f))
                        .height(6.dp)
                        .background(BullishGreen)
                )
                Box(
                    modifier = Modifier
                        .weight(bearPct.toFloat().coerceAtLeast(1f))
                        .height(6.dp)
                        .background(BearishRed)
                )
            }
        }
    }
}

@Composable
fun IndicatorMiniCard(
    title: String,
    value: String,
    subtitle: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface.copy(alpha = 0.7f))
            .border(1.dp, CardBorder.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(
                text = title,
                color = TextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                color = valueColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 9.sp,
                maxLines = 1
            )
        }
    }
}
