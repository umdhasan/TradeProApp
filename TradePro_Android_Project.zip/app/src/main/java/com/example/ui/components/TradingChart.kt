package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Candle
import com.example.model.TechnicalIndicators
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TextMuted
import kotlin.math.max
import kotlin.math.min

@Composable
fun TradingChart(
    candles: List<Candle>,
    currentPrice: Double,
    isCandleChart: Boolean,
    showIndicators: Boolean,
    indicators: TechnicalIndicators,
    priceDecimals: Int,
    modifier: Modifier = Modifier
) {
    var touchPoint by remember { mutableStateOf<Offset?>(null) }
    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }

    Box(
        modifier = modifier
            .background(CardSurface)
            .testTag("trading_chart_canvas")
    ) {
        if (candles.isEmpty()) {
            Text(
                text = "Loading real-time market stream...",
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier.align(Alignment.Center)
            )
            return@Box
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(candles) {
                    detectTapGestures(
                        onPress = { offset ->
                            touchPoint = offset
                            val widthPerCandle = size.width / candles.size
                            val index = (offset.x / widthPerCandle).toInt().coerceIn(0, candles.size - 1)
                            selectedCandleIndex = index
                            tryAwaitRelease()
                            touchPoint = null
                            selectedCandleIndex = null
                        }
                    )
                }
        ) {
            val width = size.width
            val height = size.height
            val chartHeight = height * 0.82f
            val volumeHeight = height * 0.16f
            val volumeTop = chartHeight + 4.dp.toPx()

            // Price bounds with padding
            val minPrice = (candles.minOf { it.low } * 0.9997)
            val maxPrice = (candles.maxOf { it.high } * 1.0003)
            val priceRange = max(0.00001, maxPrice - minPrice)

            val maxVolume = max(1.0, candles.maxOf { it.volume })

            fun priceToY(price: Double): Float {
                return (chartHeight - ((price - minPrice) / priceRange * chartHeight)).toFloat()
            }

            // Draw Background Grid Lines
            val gridSteps = 4
            for (i in 0..gridSteps) {
                val y = (chartHeight / gridSteps) * i
                drawLine(
                    color = CardBorder.copy(alpha = 0.4f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                )
            }

            val count = candles.size
            val candleSpacing = width / count
            val candleWidth = max(2f, candleSpacing * 0.68f)

            // 1. Draw Bollinger Bands Area & Lines
            if (showIndicators && candles.size > 20) {
                val upperY = priceToY(indicators.bbUpper)
                val middleY = priceToY(indicators.bbMiddle)
                val lowerY = priceToY(indicators.bbLower)

                // Fill channel
                drawRect(
                    color = CyberCyan.copy(alpha = 0.05f),
                    topLeft = Offset(0f, upperY),
                    size = Size(width, max(0f, lowerY - upperY))
                )
                // Upper band
                drawLine(
                    color = CyberCyan.copy(alpha = 0.45f),
                    start = Offset(0f, upperY),
                    end = Offset(width, upperY),
                    strokeWidth = 1.5f
                )
                // Middle band (SMA)
                drawLine(
                    color = CyberCyan.copy(alpha = 0.35f),
                    start = Offset(0f, middleY),
                    end = Offset(width, middleY),
                    strokeWidth = 1.2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
                // Lower band
                drawLine(
                    color = CyberCyan.copy(alpha = 0.45f),
                    start = Offset(0f, lowerY),
                    end = Offset(width, lowerY),
                    strokeWidth = 1.5f
                )

                // EMA 9 (Cyan fast line) & EMA 21 (Gold slow line)
                val ema9Y = priceToY(indicators.ema9)
                val ema21Y = priceToY(indicators.ema21)
                drawLine(
                    color = CyberCyan,
                    start = Offset(0f, ema9Y),
                    end = Offset(width, ema9Y),
                    strokeWidth = 2f
                )
                drawLine(
                    color = CryptoGold,
                    start = Offset(0f, ema21Y),
                    end = Offset(width, ema21Y),
                    strokeWidth = 2f
                )
            }

            // 2. Draw Volume Bars at bottom
            candles.forEachIndexed { i, candle ->
                val xCenter = i * candleSpacing + (candleSpacing / 2f)
                val vRatio = (candle.volume / maxVolume).toFloat()
                val vBarHeight = volumeHeight * vRatio
                val vColor = if (candle.isBullish) BullishGreen.copy(alpha = 0.3f) else BearishRed.copy(alpha = 0.3f)

                drawRect(
                    color = vColor,
                    topLeft = Offset(xCenter - (candleWidth / 2f), height - vBarHeight),
                    size = Size(candleWidth, vBarHeight)
                )
            }

            // 3. Draw Chart (Candlesticks or Line Area)
            if (isCandleChart) {
                candles.forEachIndexed { i, candle ->
                    val xCenter = i * candleSpacing + (candleSpacing / 2f)
                    val openY = priceToY(candle.open)
                    val closeY = priceToY(candle.close)
                    val highY = priceToY(candle.high)
                    val lowY = priceToY(candle.low)

                    val isBull = candle.isBullish
                    val color = if (isBull) BullishGreen else BearishRed

                    // Wick
                    drawLine(
                        color = color,
                        start = Offset(xCenter, highY),
                        end = Offset(xCenter, lowY),
                        strokeWidth = 1.5f
                    )

                    // Body
                    val bodyTop = min(openY, closeY)
                    val bodyHeight = max(2f, kotlin.math.abs(closeY - openY))

                    drawRect(
                        color = color,
                        topLeft = Offset(xCenter - (candleWidth / 2f), bodyTop),
                        size = Size(candleWidth, bodyHeight)
                    )
                }
            } else {
                // Area Line Chart
                val linePath = Path()
                val fillPath = Path()

                candles.forEachIndexed { i, candle ->
                    val x = i * candleSpacing + (candleSpacing / 2f)
                    val y = priceToY(candle.close)

                    if (i == 0) {
                        linePath.moveTo(x, y)
                        fillPath.moveTo(x, chartHeight)
                        fillPath.lineTo(x, y)
                    } else {
                        linePath.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                }

                val lastX = (candles.size - 1) * candleSpacing + (candleSpacing / 2f)
                fillPath.lineTo(lastX, chartHeight)
                fillPath.close()

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(CyberCyan.copy(alpha = 0.35f), Color.Transparent),
                        startY = 0f,
                        endY = chartHeight
                    )
                )

                drawPath(
                    path = linePath,
                    color = CyberCyan,
                    style = Stroke(width = 2.5f)
                )
            }

            // 4. Draw Current Live Price Line & Pulsing Dot
            val currentY = priceToY(currentPrice)
            val isCurrentBullish = candles.last().isBullish
            val liveColor = if (isCurrentBullish) BullishGreen else BearishRed

            drawLine(
                color = liveColor,
                start = Offset(0f, currentY),
                end = Offset(width, currentY),
                strokeWidth = 1.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
            )

            val lastX = (candles.size - 1) * candleSpacing + (candleSpacing / 2f)
            drawCircle(
                color = liveColor,
                radius = 5f,
                center = Offset(lastX, currentY)
            )
            drawCircle(
                color = liveColor.copy(alpha = 0.35f),
                radius = 11f,
                center = Offset(lastX, currentY)
            )

            // 5. Draw Crosshair if touched
            touchPoint?.let { pt ->
                drawLine(
                    color = Color.White.copy(alpha = 0.6f),
                    start = Offset(pt.x, 0f),
                    end = Offset(pt.x, height),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.6f),
                    start = Offset(0f, pt.y),
                    end = Offset(width, pt.y),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                )
            }
        }

        // Inspection tooltip
        selectedCandleIndex?.let { idx ->
            val c = candles.getOrNull(idx)
            if (c != null) {
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .background(CardSurface.copy(alpha = 0.92f), MaterialTheme.shapes.small)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = "O: ${c.open}  H: ${c.high}  L: ${c.low}  C: ${c.close}  Vol: ${c.volume.toInt()}",
                        color = if (c.isBullish) BullishGreen else BearishRed,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
