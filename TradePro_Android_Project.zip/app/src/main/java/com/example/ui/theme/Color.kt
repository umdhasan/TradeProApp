package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF00B4D8)
val DarkNavyBg = Color(0xFF090D16)
val CardSurface = Color(0xFF0F1726)
val CardSurfaceElevated = Color(0xFF162035)
val CardBorder = Color(0xFF23314A)

// Trading Action Colors
val BullishGreen = Color(0xFF00E676)
val BullishGreenDark = Color(0xFF00B359)
val BullishGreenBg = Color(0x1F00E676)

val BearishRed = Color(0xFFFF3358)
val BearishRedDark = Color(0xFFD91B3E)
val BearishRedBg = Color(0x1FFF3358)

val WarningYellow = Color(0xFFFFD600)
val WarningYellowBg = Color(0x1FFFD600)

// Market Category Colors
val DigitalTeal = Color(0xFF14B8A6)
val BlitzPurple = Color(0xFFA855F7)
val BinaryBlue = Color(0xFF38BDF8)
val CryptoGold = Color(0xFFF59E0B)

// Neutral Text & Icons
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

