package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AlertNotificationEntity
import com.example.database.AlertRuleEntity
import com.example.database.SignalEntity
import com.example.database.TradeEntity
import com.example.database.TradeProDatabase
import com.example.engine.AlertEngine
import com.example.engine.AlertSoundManager
import com.example.engine.MarketEngine
import com.example.engine.SignalEngine
import com.example.engine.TechnicalAnalysisEngine
import com.example.model.AlertNotification
import com.example.model.AlertRule
import com.example.model.AlertType
import com.example.model.ExpiryTime
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.SignalDirection
import com.example.model.SignalOutcome
import com.example.model.SimulationTrade
import com.example.model.TechnicalIndicators
import com.example.model.TradingAsset
import com.example.model.TradingSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class NavigationTab(val title: String) {
    MARKETS("Markets"),
    TERMINAL("Terminal"),
    SIGNALS("AI Bot"),
    ALERTS("Alerts"),
    JOURNAL("Journal")
}

class TradeProViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TradeProDatabase.getDatabase(application)
    val soundManager = AlertSoundManager(application)
    val marketEngine = MarketEngine(viewModelScope)
    val alertEngine = AlertEngine(viewModelScope, db.alertDao(), marketEngine, soundManager)

    // Navigation
    private val _currentTab = MutableStateFlow(NavigationTab.TERMINAL)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    // Market Filtering
    private val _selectedCategory = MutableStateFlow<MarketCategory?>(null) // null = ALL
    val selectedCategory: StateFlow<MarketCategory?> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Terminal & Chart State
    val selectedAssetId: StateFlow<String> = marketEngine.selectedAssetId
    val allAssets: StateFlow<List<TradingAsset>> = marketEngine.assets

    val selectedAsset: StateFlow<TradingAsset?> = combine(allAssets, selectedAssetId) { assets, id ->
        assets.firstOrNull { it.id == id } ?: assets.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _selectedTimeframe = MutableStateFlow(ExpiryTime.MIN_1)
    val selectedTimeframe: StateFlow<ExpiryTime> = _selectedTimeframe.asStateFlow()

    private val _isCandleChart = MutableStateFlow(true)
    val isCandleChart: StateFlow<Boolean> = _isCandleChart.asStateFlow()

    private val _showIndicators = MutableStateFlow(true)
    val showIndicators: StateFlow<Boolean> = _showIndicators.asStateFlow()

    // AI Signal Bot State
    private val _selectedPlatform = MutableStateFlow(MarketPlatform.QUOTEX)
    val selectedPlatform: StateFlow<MarketPlatform> = _selectedPlatform.asStateFlow()

    private val _isGeneratingSignal = MutableStateFlow(false)
    val isGeneratingSignal: StateFlow<Boolean> = _isGeneratingSignal.asStateFlow()

    private val _activeSignal = MutableStateFlow<TradingSignal?>(null)
    val activeSignal: StateFlow<TradingSignal?> = _activeSignal.asStateFlow()

    // Simulation & Balance
    private val _demoBalance = MutableStateFlow(10000.0)
    val demoBalance: StateFlow<Double> = _demoBalance.asStateFlow()

    private val _tradeAmount = MutableStateFlow(25.0)
    val tradeAmount: StateFlow<Double> = _tradeAmount.asStateFlow()

    private val _activeTrades = MutableStateFlow<List<SimulationTrade>>(emptyList())
    val activeTrades: StateFlow<List<SimulationTrade>> = _activeTrades.asStateFlow()

    // Room Database Flows
    val savedSignals: StateFlow<List<SignalEntity>> = db.signalDao().getAllSignals()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val alertRules: StateFlow<List<AlertRuleEntity>> = db.alertDao().getAllRules()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val alertNotifications: StateFlow<List<AlertNotificationEntity>> = db.alertDao().getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val tradeHistory: StateFlow<List<TradeEntity>> = db.tradeDao().getAllTrades()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Technical indicators for selected asset
    val technicalIndicators: StateFlow<TechnicalIndicators> = selectedAsset.combine(_selectedTimeframe) { asset, _ ->
        if (asset != null) TechnicalAnalysisEngine.analyze(asset.candles)
        else TechnicalAnalysisEngine.analyze(emptyList())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, TechnicalAnalysisEngine.analyze(emptyList()))

    init {
        startTradeResolutionLoop()
    }

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun selectCategory(category: MarketCategory?) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectAsset(assetId: String) {
        marketEngine.selectAsset(assetId)
        soundManager.playClickSound()
    }

    fun setTimeframe(expiry: ExpiryTime) {
        _selectedTimeframe.value = expiry
    }

    fun toggleChartType() {
        _isCandleChart.value = !_isCandleChart.value
    }

    fun toggleIndicators() {
        _showIndicators.value = !_showIndicators.value
    }

    fun setPlatform(platform: MarketPlatform) {
        _selectedPlatform.value = platform
    }

    fun setTradeAmount(amount: Double) {
        _tradeAmount.value = amount
    }

    fun generateSignalForSelectedAsset() {
        val asset = selectedAsset.value ?: return
        viewModelScope.launch {
            _isGeneratingSignal.value = true
            soundManager.playClickSound()
            delay(1200L) // AI scanning simulation

            val indicators = technicalIndicators.value
            val signal = SignalEngine.generateSignal(
                asset = asset,
                indicators = indicators,
                platform = _selectedPlatform.value,
                expiryTime = _selectedTimeframe.value,
                baseTradeAmount = _tradeAmount.value
            )
            _activeSignal.value = signal
            _isGeneratingSignal.value = false

            if (signal.direction == SignalDirection.CALL) {
                soundManager.playCallAlert()
            } else {
                soundManager.playPutAlert()
            }

            // Save to room
            launch(Dispatchers.IO) {
                db.signalDao().insertSignal(
                    SignalEntity(
                        id = signal.id,
                        assetId = signal.assetId,
                        assetSymbol = signal.assetSymbol,
                        categoryName = signal.assetCategory.name,
                        direction = signal.direction.name,
                        confidence = signal.confidence,
                        strikePrice = signal.strikePrice,
                        expirySeconds = signal.expiryTime.seconds,
                        platformName = signal.platform.displayName,
                        strategyName = signal.strategyName,
                        rsiValue = signal.rsiValue,
                        macdTrend = signal.macdTrend,
                        timestamp = signal.timestamp,
                        outcome = signal.outcome.name,
                        resultPnl = signal.resultPnl
                    )
                )
            }
        }
    }

    fun executeTrade(direction: SignalDirection) {
        val asset = selectedAsset.value ?: return
        val amount = _tradeAmount.value
        if (_demoBalance.value < amount) return

        _demoBalance.value -= amount
        soundManager.playClickSound()

        val trade = SimulationTrade(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            category = asset.category,
            direction = direction,
            investment = amount,
            entryPrice = asset.currentPrice,
            payoutPercent = asset.payoutPercent,
            expirySeconds = _selectedTimeframe.value.seconds,
            platform = _selectedPlatform.value
        )

        _activeTrades.value = _activeTrades.value + trade
    }

    private fun startTradeResolutionLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(500L)
                val now = System.currentTimeMillis()
                val currentTrades = _activeTrades.value
                val remaining = mutableListOf<SimulationTrade>()

                for (trade in currentTrades) {
                    if (now >= trade.closeTime) {
                        // Resolve trade outcome
                        val asset = allAssets.value.firstOrNull { it.id == trade.assetId }
                        val exitPrice = asset?.currentPrice ?: trade.entryPrice
                        val isWin = if (trade.direction == SignalDirection.CALL) {
                            exitPrice > trade.entryPrice
                        } else {
                            exitPrice < trade.entryPrice
                        }

                        val outcome = if (isWin) SignalOutcome.WIN else SignalOutcome.LOSS
                        val profit = if (isWin) trade.investment * (trade.payoutPercent / 100.0) else -trade.investment

                        if (isWin) {
                            _demoBalance.value += (trade.investment + profit)
                            soundManager.playCallAlert()
                        } else {
                            soundManager.playPutAlert()
                        }

                        // Save to trade history
                        val tradeEntity = TradeEntity(
                            id = trade.id,
                            assetId = trade.assetId,
                            assetSymbol = trade.assetSymbol,
                            categoryName = trade.category.name,
                            direction = trade.direction.name,
                            investment = trade.investment,
                            entryPrice = trade.entryPrice,
                            exitPrice = exitPrice,
                            payoutPercent = trade.payoutPercent,
                            expirySeconds = trade.expirySeconds,
                            openTime = trade.openTime,
                            closeTime = trade.closeTime,
                            outcome = outcome.name,
                            profit = profit,
                            platformName = trade.platform.displayName
                        )
                        launch(Dispatchers.IO) {
                            db.tradeDao().insertTrade(tradeEntity)
                        }
                    } else {
                        remaining.add(trade)
                    }
                }
                _activeTrades.value = remaining
            }
        }
    }

    fun addCustomPriceAlert(asset: TradingAsset, targetPrice: Double, isAbove: Boolean) {
        val type = if (isAbove) AlertType.PRICE_ABOVE else AlertType.PRICE_BELOW
        val rule = AlertRule(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            type = type,
            targetValue = targetPrice
        )
        alertEngine.addCustomAlertRule(rule)
        soundManager.playClickSound()
    }

    fun addCustomRsiAlert(asset: TradingAsset, isOversold: Boolean) {
        val type = if (isOversold) AlertType.RSI_OVERSOLD else AlertType.RSI_OVERBOUGHT
        val target = if (isOversold) 30.0 else 70.0
        val rule = AlertRule(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            type = type,
            targetValue = target
        )
        alertEngine.addCustomAlertRule(rule)
        soundManager.playClickSound()
    }

    fun deleteAlertRule(ruleId: String) {
        alertEngine.deleteCustomAlertRule(ruleId)
    }

    fun markNotificationsRead() {
        viewModelScope.launch(Dispatchers.IO) {
            db.alertDao().markAllAsRead()
        }
    }

    fun clearNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            db.alertDao().clearNotifications()
        }
    }

    fun resetDemoBalance() {
        _demoBalance.value = 10000.0
        soundManager.playClickSound()
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
