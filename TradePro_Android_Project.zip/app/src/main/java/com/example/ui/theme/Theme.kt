package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TradingDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = DarkNavyBg,
    primaryContainer = CardSurfaceElevated,
    onPrimaryContainer = CyberCyan,
    secondary = BullishGreen,
    onSecondary = DarkNavyBg,
    secondaryContainer = BullishGreenBg,
    onSecondaryContainer = BullishGreen,
    tertiary = BearishRed,
    onTertiary = TextPrimary,
    tertiaryContainer = BearishRedBg,
    onTertiaryContainer = BearishRed,
    background = DarkNavyBg,
    onBackground = TextPrimary,
    surface = CardSurface,
    onSurface = TextPrimary,
    surfaceVariant = CardSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    outlineVariant = CardBorder
)

@Composable
fun TradeProTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TradingDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TradeProTheme(content = content)
}
