package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.AlertNotificationEntity
import com.example.database.AlertRuleEntity
import com.example.model.AlertType
import com.example.model.TradingAsset
import com.example.ui.TradeProViewModel
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AlertsScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val isAutoScannerActive by viewModel.alertEngine.isAutoScannerActive.collectAsState()
    val minConfidence by viewModel.alertEngine.minConfidenceThreshold.collectAsState()
    val alertRules by viewModel.alertRules.collectAsState()
    val notifications by viewModel.alertNotifications.collectAsState()
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .padding(horizontal = 14.dp)
            .testTag("alerts_screen")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Scanner Master Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isAutoScannerActive) CyberCyan.copy(alpha = 0.2f) else CardSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Radar,
                                contentDescription = null,
                                tint = if (isAutoScannerActive) CyberCyan else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "AUTOMATED MARKET SCANNER",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAutoScannerActive) "Scanning Digital, Blitz & Crypto 24/7" else "Scanner Paused",
                                color = if (isAutoScannerActive) BullishGreen else TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = isAutoScannerActive,
                        onCheckedChange = { viewModel.alertEngine.setAutoScannerActive(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberCyan,
                            checkedTrackColor = CyberCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CardSurfaceElevated
                        ),
                        modifier = Modifier.testTag("auto_scanner_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Threshold Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Trigger on AI Confidence:", color = TextSecondary, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(80, 85, 90).forEach { threshold ->
                            val isSel = minConfidence == threshold
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurfaceElevated)
                                    .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.alertEngine.setMinConfidenceThreshold(threshold) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = ">=$threshold%",
                                    color = if (isSel) CyberCyan else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Audio Tone Sound Tester
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Test Alert Chimes:", color = TextMuted, fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TestSoundChip("Call Chime", BullishGreen) { viewModel.soundManager.playCallAlert() }
                        TestSoundChip("Put Chime", BearishRed) { viewModel.soundManager.playPutAlert() }
                        TestSoundChip("Urgent Siren", CryptoGold) { viewModel.soundManager.playUrgentAlert() }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Custom Alerts Header & Action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CUSTOM PRICE & TECHNICAL ALERTS",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp).testTag("add_custom_alert_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Set Alert", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Custom Alert Rules List
        if (alertRules.isNotEmpty()) {
            alertRules.take(3).forEach { rule ->
                CustomAlertRuleRow(
                    rule = rule,
                    onDelete = { viewModel.deleteAlertRule(rule.id) }
                )
                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Alert Feed Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "TRIGGERED ALERTS FEED (${notifications.size})",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (notifications.isNotEmpty()) {
                Text(
                    text = "Clear All",
                    color = BearishRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.clearNotifications() }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Notification Feed List
        if (notifications.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No alerts triggered yet. Scanner is monitoring in background.",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(notifications, key = { it.id }) { notif ->
                    NotificationCard(notif = notif)
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }

    // Dialog for Creating Custom Alert
    if (showCreateDialog) {
        CreateAlertDialog(
            selectedAsset = selectedAsset ?: allAssets.first(),
            allAssets = allAssets,
            onDismiss = { showCreateDialog = false },
            onSavePriceAlert = { target, isAbove ->
                selectedAsset?.let { viewModel.addCustomPriceAlert(it, target, isAbove) }
                showCreateDialog = false
            },
            onSaveRsiAlert = { isOversold ->
                selectedAsset?.let { viewModel.addCustomRsiAlert(it, isOversold) }
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun TestSoundChip(label: String, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = color, modifier = Modifier.size(11.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun CustomAlertRuleRow(rule: AlertRuleEntity, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "${rule.assetSymbol} • ${rule.alertType}",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Target: ${rule.targetValue} • Audio & Haptic ON",
                color = TextMuted,
                fontSize = 10.sp
            )
        }

        IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "Delete Alert", tint = BearishRed, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
fun NotificationCard(notif: AlertNotificationEntity) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val isSignal = notif.alertType.contains("SIGNAL") || notif.title.contains("CALL") || notif.title.contains("PUT")
    val badgeColor = if (notif.title.contains("CALL")) BullishGreen else if (notif.title.contains("PUT")) BearishRed else CyberCyan

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(badgeColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = notif.title,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = dateFormat.format(Date(notif.timestamp)),
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = notif.message,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun CreateAlertDialog(
    selectedAsset: TradingAsset,
    allAssets: List<TradingAsset>,
    onDismiss: () -> Unit,
    onSavePriceAlert: (Double, Boolean) -> Unit,
    onSaveRsiAlert: (Boolean) -> Unit
) {
    var priceInput by remember { mutableStateOf(selectedAsset.currentPrice.toString()) }
    var alertMode by remember { mutableStateOf("PRICE_ABOVE") } // PRICE_ABOVE, PRICE_BELOW, RSI_OS, RSI_OB

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardSurfaceElevated,
        title = {
            Text("Set Alert on ${selectedAsset.symbol}", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text("Select Condition Type:", color = TextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ConditionChip("Price > Target", alertMode == "PRICE_ABOVE") { alertMode = "PRICE_ABOVE" }
                    ConditionChip("Price < Target", alertMode == "PRICE_BELOW") { alertMode = "PRICE_BELOW" }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ConditionChip("RSI Oversold <30", alertMode == "RSI_OS") { alertMode = "RSI_OS" }
                    ConditionChip("RSI Overbought >70", alertMode == "RSI_OB") { alertMode = "RSI_OB" }
                }

                if (alertMode.startsWith("PRICE")) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Target Price (Current: ${selectedAsset.currentPrice})", color = TextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = priceInput,
                        onValueChange = { priceInput = it },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CardSurface,
                            unfocusedContainerColor = CardSurface,
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (alertMode == "PRICE_ABOVE") {
                        val p = priceInput.toDoubleOrNull() ?: selectedAsset.currentPrice
                        onSavePriceAlert(p, true)
                    } else if (alertMode == "PRICE_BELOW") {
                        val p = priceInput.toDoubleOrNull() ?: selectedAsset.currentPrice
                        onSavePriceAlert(p, false)
                    } else if (alertMode == "RSI_OS") {
                        onSaveRsiAlert(true)
                    } else {
                        onSaveRsiAlert(false)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
            ) {
                Text("Activate Alert", color = DarkNavyBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun ConditionChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else CardSurface)
            .border(1.dp, if (isSelected) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) CyberCyan else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
