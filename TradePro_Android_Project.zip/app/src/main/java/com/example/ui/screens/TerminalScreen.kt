package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.ExpiryTime
import com.example.model.MarketPlatform
import com.example.model.SignalDirection
import com.example.model.SimulationTrade
import com.example.ui.TradeProViewModel
import com.example.ui.components.TechnicalIndicatorsPanel
import com.example.ui.components.TradingChart
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TerminalScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val indicators by viewModel.technicalIndicators.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val isCandleChart by viewModel.isCandleChart.collectAsState()
    val showIndicators by viewModel.showIndicators.collectAsState()
    val selectedPlatform by viewModel.selectedPlatform.collectAsState()
    val demoBalance by viewModel.demoBalance.collectAsState()
    val tradeAmount by viewModel.tradeAmount.collectAsState()
    val activeTrades by viewModel.activeTrades.collectAsState()

    var assetMenuExpanded by remember { mutableStateOf(false) }
    var platformMenuExpanded by remember { mutableStateOf(false) }
    var showWebView by remember { mutableStateOf(false) }

    val platformUrl = when (selectedPlatform) {
        MarketPlatform.QUOTEX -> "https://qxbroker.com"
        MarketPlatform.POCKET_OPTION -> "https://pocketoption.com"
        MarketPlatform.IQ_OPTION -> "https://iqoption.com"
        MarketPlatform.BINOMO -> "https://binomo.com"
        MarketPlatform.DERIV -> "https://app.deriv.com"
        MarketPlatform.OLYMP_TRADE -> "https://olymptrade.com"
    }

    val asset = selectedAsset ?: return

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 12.dp)
            .testTag("terminal_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Top Bar: Asset Selector & Platform Selector & Demo Balance
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Asset Dropdown Button
            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardSurface)
                        .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                        .clickable { assetMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = asset.symbol,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = "Select Asset",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = assetMenuExpanded,
                    onDismissRequest = { assetMenuExpanded = false },
                    modifier = Modifier.background(CardSurfaceElevated)
                ) {
                    allAssets.forEach { a ->
                        DropdownMenuItem(
                            text = {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(a.symbol, color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text("${a.payoutPercent}%", color = BullishGreen, fontSize = 12.sp)
                                }
                            },
                            onClick = {
                                viewModel.selectAsset(a.id)
                                assetMenuExpanded = false
                            }
                        )
                    }
                }
            }

            // Broker Platform Dropdown
            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardSurface)
                        .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                        .clickable { platformMenuExpanded = true }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedPlatform.displayName,
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = "Broker Platform",
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = platformMenuExpanded,
                    onDismissRequest = { platformMenuExpanded = false },
                    modifier = Modifier.background(CardSurfaceElevated)
                ) {
                    MarketPlatform.values().forEach { p ->
                        DropdownMenuItem(
                            text = { Text(p.displayName, color = TextPrimary) },
                            onClick = {
                                viewModel.setPlatform(p)
                                platformMenuExpanded = false
                            }
                        )
                    }
                }
            }

            // Demo Balance
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DEMO: $",
                    color = TextMuted,
                    fontSize = 11.sp
                )
                Text(
                    text = String.format("%,.0f", demoBalance),
                    color = BullishGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Price Header & 24h Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = String.format("%.${asset.priceDecimals}f", asset.currentPrice),
                        color = if (asset.isUp) BullishGreen else BearishRed,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (asset.change24h >= 0) BullishGreen.copy(alpha = 0.15f) else BearishRed.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${if (asset.change24h >= 0) "+" else ""}${String.format("%.2f", asset.change24h)}%",
                            color = if (asset.change24h >= 0) BullishGreen else BearishRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "${asset.name} • Payout ${asset.payoutPercent}%",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            // Chart View Controls (Candle / Line & Indicators Toggle)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { viewModel.toggleChartType() },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isCandleChart) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                ) {
                    Icon(
                        imageVector = if (isCandleChart) Icons.Default.CandlestickChart else Icons.Default.ShowChart,
                        contentDescription = "Toggle Chart Type",
                        tint = if (isCandleChart) CyberCyan else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = { viewModel.toggleIndicators() },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (showIndicators) CryptoGold.copy(alpha = 0.2f) else CardSurface)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoGraph,
                        contentDescription = "Toggle Indicators",
                        tint = if (showIndicators) CryptoGold else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Timeframe Selector Chips (5s Blitz, 15s, 30s, 1m, 2m, 5m)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(ExpiryTime.values()) { expiry ->
                val isSelected = selectedTimeframe == expiry
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                        .border(1.dp, if (isSelected) CyberCyan else CardBorder, RoundedCornerShape(8.dp))
                        .clickable { viewModel.setTimeframe(expiry) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = expiry.label,
                        color = if (isSelected) CyberCyan else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // View Mode Switcher: Chart vs Platform WebView
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(CardSurface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (!showWebView) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                    .clickable { showWebView = false }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "📊 AI Analysis & Chart",
                    color = if (!showWebView) CyberCyan else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (showWebView) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                    .clickable { showWebView = true }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🌐 ${selectedPlatform.displayName} Web",
                    color = if (showWebView) CyberCyan else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Chart or Broker WebView Area
        if (!showWebView) {
            TradingChart(
                candles = asset.candles,
                currentPrice = asset.currentPrice,
                isCandleChart = isCandleChart,
                showIndicators = showIndicators,
                indicators = indicators,
                priceDecimals = asset.priceDecimals,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                    .background(CardSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardSurfaceElevated)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Broker Portal: ${selectedPlatform.displayName}",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberCyan.copy(alpha = 0.15f))
                            .clickable {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(platformUrl))
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Open in External Browser",
                            tint = CyberCyan,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Open in Browser",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(520.dp),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                mediaPlaybackRequiresUserGesture = true
                                databaseEnabled = true
                                userAgentString = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                            }
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                    if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                                        return false
                                    }
                                    return true
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    errorCode: Int,
                                    description: String?,
                                    failingUrl: String?
                                ) {
                                    // Suppress unhandled network error popups on socket drops
                                }
                            }
                            loadUrl(platformUrl)
                        }
                    },
                    update = { webView ->
                        if (webView.url != platformUrl) {
                            webView.loadUrl(platformUrl)
                        }
                    },
                    onRelease = { webView ->
                        try {
                            webView.stopLoading()
                            webView.clearHistory()
                            webView.loadUrl("about:blank")
                            webView.onPause()
                            webView.removeAllViews()
                            webView.destroy()
                        } catch (_: Exception) {}
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Real-Time Indicators & Sentiment Gauge
        TechnicalIndicatorsPanel(indicators = indicators)

        Spacer(modifier = Modifier.height(12.dp))

        // Active In-Flight Trades
        if (activeTrades.isNotEmpty()) {
            Text(
                text = "ACTIVE TRADES IN EXPIRY",
                color = CryptoGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            activeTrades.forEach { trade ->
                ActiveTradeRow(trade = trade)
                Spacer(modifier = Modifier.height(6.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Trade Execution Panel
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                .padding(bottom = 8.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TRADE INVESTMENT",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    val expectedProfit = tradeAmount * (asset.payoutPercent / 100.0)
                    Text(
                        text = "Profit: +$${String.format("%.2f", expectedProfit)} (+${asset.payoutPercent}%)",
                        color = BullishGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Investment Presets ($5, $10, $25, $50, $100, $250)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val presets = listOf(5.0, 10.0, 25.0, 50.0, 100.0, 250.0)
                    items(presets) { amt ->
                        val isSel = tradeAmount == amt
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurfaceElevated)
                                .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                                .clickable { viewModel.setTradeAmount(amt) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "$${amt.toInt()}",
                                color = if (isSel) CyberCyan else TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Big Call (BUY UP) & Put (SELL DOWN) Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // CALL BUTTON
                    Button(
                        onClick = { viewModel.executeTrade(SignalDirection.CALL) },
                        colors = ButtonDefaults.buttonColors(containerColor = BullishGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("terminal_call_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowUpward,
                            contentDescription = "CALL",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("CALL / BUY", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${selectedTimeframe.label} UP", color = Color.Black.copy(alpha = 0.8f), fontSize = 9.sp)
                        }
                    }

                    // PUT BUTTON
                    Button(
                        onClick = { viewModel.executeTrade(SignalDirection.PUT) },
                        colors = ButtonDefaults.buttonColors(containerColor = BearishRed),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("terminal_put_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowDownward,
                            contentDescription = "PUT",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("PUT / SELL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${selectedTimeframe.label} DOWN", color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
fun ActiveTradeRow(trade: SimulationTrade) {
    val remainingMs = maxOf(0L, trade.closeTime - System.currentTimeMillis())
    val remainingSec = (remainingMs / 1000L).toInt()

    val isCall = trade.direction == SignalDirection.CALL
    val dirColor = if (isCall) BullishGreen else BearishRed

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface)
            .border(1.dp, dirColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(dirColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = dirColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "${trade.assetSymbol} ${trade.direction.name}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Entry: ${trade.entryPrice} • Inv: $${trade.investment.toInt()}",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }

        // Countdown Timer
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Timer,
                contentDescription = "Timer",
                tint = CryptoGold,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "${remainingSec}s",
                color = CryptoGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

