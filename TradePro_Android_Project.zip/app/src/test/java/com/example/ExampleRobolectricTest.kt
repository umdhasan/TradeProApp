package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.SignalEngine
import com.example.engine.TechnicalAnalysisEngine
import com.example.model.Candle
import com.example.model.ExpiryTime
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.TradingAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TradePro", appName)
  }

  @Test
  fun `technical indicators and signal generation`() {
    val candles = (1..30).map { i ->
      Candle(
        open = 100.0 + i * 0.1,
        high = 100.5 + i * 0.1,
        low = 99.8 + i * 0.1,
        close = 100.2 + i * 0.1,
        volume = 50.0 + i,
        timestamp = System.currentTimeMillis() + i * 1000L
      )
    }

    val indicators = TechnicalAnalysisEngine.analyze(candles)
    assertTrue(indicators.rsi14 in 0.0..100.0)
    assertTrue(indicators.bbUpper >= indicators.bbLower)

    val asset = TradingAsset(
      id = "test_eurusd",
      symbol = "EUR/USD",
      name = "Euro / US Dollar",
      category = MarketCategory.DIGITAL,
      basePrice = 1.08200,
      currentPrice = 1.08500,
      prevPrice = 1.08480,
      change24h = 0.28,
      high24h = 1.08650,
      low24h = 1.08100,
      payoutPercent = 95,
      candles = candles
    )

    val signal = SignalEngine.generateSignal(
      asset = asset,
      indicators = indicators,
      platform = MarketPlatform.QUOTEX,
      expiryTime = ExpiryTime.MIN_1,
      baseTradeAmount = 10.0
    )

    assertNotNull(signal)
    assertTrue(signal.confidence in 50..100)
    assertTrue(signal.martingaleStep1 > 10.0)
  }
}
